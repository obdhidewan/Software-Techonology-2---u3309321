import timeit

# Recursive implementations
def sum_of_natural_numbers(n):
    if n <= 1:
        return n
    return n + sum_of_natural_numbers(n - 1)

def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    return fibonacci(n - 1) + fibonacci(n - 2)

def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n - 1)

# Iterative implementations
def sum_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a = 0
    b = 1
    for i in range(2, n + 1):
        temp = a + b
        a = b
        b = temp
    return b

def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Safe data sizes
sum_sizes = [10, 50, 100]
factorial_sizes = [5, 10, 15]
fibonacci_sizes = [5, 10, 15]

# Test sum of natural numbers
print("----- Sum of Natural Numbers -----")
for n in sum_sizes:
    rec_time = timeit.timeit(lambda: sum_of_natural_numbers(n), number=1000)
    iter_time = timeit.timeit(lambda: sum_iterative(n), number=1000)
    print(f"n = {n} | Recursive: {rec_time:.6f}s | Iterative: {iter_time:.6f}s")

# Test factorial
print("\n----- Factorial -----")
for n in factorial_sizes:
    rec_time = timeit.timeit(lambda: factorial(n), number=1000)
    iter_time = timeit.timeit(lambda: factorial_iterative(n), number=1000)
    print(f"n = {n} | Recursive: {rec_time:.6f}s | Iterative: {iter_time:.6f}s")

# Test Fibonacci
print("\n----- Fibonacci -----")
for n in fibonacci_sizes:
    rec_time = timeit.timeit(lambda: fibonacci(n), number=1)
    iter_time = timeit.timeit(lambda: fibonacci_iterative(n), number=1)
    print(f"n = {n} | Recursive: {rec_time:.6f}s | Iterative: {iter_time:.6f}s")