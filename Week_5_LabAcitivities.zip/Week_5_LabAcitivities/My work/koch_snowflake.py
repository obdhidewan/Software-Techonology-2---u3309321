from tkinter import *  # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()  # Create a window
        window.title("Koch Snowflake")  # Set a title

        self.width = 500
        self.height = 500

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button
        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)

        self.order = StringVar()

        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)

        Button(frame1,
               text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        # Define three points of the triangle
        p1 = [self.width / 2, 50]
        p2 = [50, self.height - 120]
        p3 = [self.width - 50, self.height - 120]

        order = int(self.order.get())

        # Draw three sides of the snowflake
        self.displayKoch(order, p1, p2)
        self.displayKoch(order, p2, p3)
        self.displayKoch(order, p3, p1)

    def displayKoch(self, order, p1, p2):
        if order == 0:  # Base condition
            self.drawLine(p1, p2)
        else:
            # Get points that divide the line into three parts
            x1, y1 = p1
            x5, y5 = p2

            p2 = [x1 + (x5 - x1) / 3, y1 + (y5 - y1) / 3]
            p4 = [x1 + 2 * (x5 - x1) / 3, y1 + 2 * (y5 - y1) / 3]

            # Calculate the peak point of the triangle
            x3 = (x1 + x5) / 2 - math.sqrt(3) * (y5 - y1) / 6
            y3 = (y1 + y5) / 2 + math.sqrt(3) * (x5 - x1) / 6
            p3 = [x3, y3]

            # Recursively draw four smaller segments
            self.displayKoch(order - 1, p1, p2)
            self.displayKoch(order - 1, p2, p3)
            self.displayKoch(order - 1, p3, p4)
            self.displayKoch(order - 1, p4, [x5, y5])

    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")


KochSnowflake()