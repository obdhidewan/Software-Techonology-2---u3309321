import unittest
import sys
import os

# --- TUTOR'S WEEK 10-12 LOGIC VERIFICATION ---
# Manually adding the project root to the path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# These imports match your exact file names (note the 's' in visualiser)
from modules.data_structures import Stack, LinkedList, insert_bst
from modules.heap_visualiser import MinHeap

class TestDSALogic(unittest.TestCase):
    def setUp(self):
        # Week 10: Stack implementation
        self.stack = Stack()

    def test_week10_stack(self):
        self.stack.push("A")
        self.assertEqual(self.stack.pop(), "A")

    def test_week11_bst(self):
        # Week 11: Recursive BST logic
        root = insert_bst(None, 50)
        root = insert_bst(root, 30)
        self.assertEqual(root.left.data, 30)

    def test_week12_heap(self):
        # Week 12: Min-Heap bubble-up logic
        heap = MinHeap()
        heap.insert(100)
        heap.insert(20)
        self.assertEqual(heap.heap[0], 20)

if __name__ == '__main__':
    unittest.main()