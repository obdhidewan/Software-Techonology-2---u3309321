# main.py

import pygame
import sys

# --- MODULE IMPORTS ---
from modules.data_structures import data_structures_module
from modules.linked_list import linked_list_module
from modules.bst_visualiser import bst_module
from modules.linear_search import linear_search_module
from modules.sorting_visualiser import sorting_module
from modules.graph_visualiser import graphs_module
from modules.heap_visualiser import heap_module
from modules.dp_visualiser import puzzles_module
from modules.pathfinding_visualiser import pathfinding_module

pygame.init()
WIDTH, HEIGHT = 850, 650
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser App")

FONT = pygame.font.SysFont(None, 30)
TITLE_FONT = pygame.font.SysFont(None, 48)
clock = pygame.time.Clock()


def draw_text(text, pos, font=FONT):
    txt = font.render(text, True, (0, 0, 0))
    screen.blit(txt, pos)


def main_menu():
    screen.fill((220, 220, 240))
    draw_text("DSA Explorer & Visualiser", (WIDTH // 4, 40), TITLE_FONT)

    # Organized by Phases
    buttons = {
        # Phase 1
        'Stack & Queue': pygame.Rect(100, 150, 280, 50),
        'Linked List': pygame.Rect(100, 220, 280, 50),
        'BST Visualiser': pygame.Rect(100, 290, 280, 50),
        'Linear Search': pygame.Rect(100, 360, 280, 50),

        # Phase 2 & 3
        'Sorting': pygame.Rect(470, 150, 280, 50),
        'Graphs': pygame.Rect(470, 220, 280, 50),
        'Heap': pygame.Rect(470, 290, 280, 50),
        'Puzzles (DP)': pygame.Rect(470, 360, 280, 50)
    }

    for text, rect in buttons.items():
        color = (170, 170, 220) if rect.x < 400 else (150, 200, 200)
        pygame.draw.rect(screen, color, rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        draw_text(text, (rect.x + 25, rect.y + 15))

    pygame.display.flip()
    return buttons


def main():
    running = True
    current_module = None

    while running:
        if current_module is None:
            buttons = main_menu()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    for name, rect in buttons.items():
                        if rect.collidepoint(pos):
                            current_module = name
        else:
            # Execute specific module based on selection
            if current_module == 'Stack & Queue':
                data_structures_module(screen, clock)
            elif current_module == 'Linked List':
                linked_list_module(screen, clock)
            elif current_module == 'BST Visualiser':
                bst_module(screen, clock)
            elif current_module == 'Linear Search':
                linear_search_module(screen, clock)
            elif current_module == 'Sorting':
                sorting_module(screen, clock)
            elif current_module == 'Graphs':
                graphs_module(screen, clock)
            elif current_module == 'Heap':
                heap_module(screen, clock)
            elif current_module == 'Puzzles (DP)':
                puzzles_module(screen, clock)

            current_module = None  # Return to menu after module exits

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()