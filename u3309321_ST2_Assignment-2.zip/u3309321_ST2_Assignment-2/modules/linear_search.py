# modules/linear_search.py

import pygame
import sys


# --- BUTTON UI HELPERS  ---

def draw_buttons(screen, font):
    #Draws controls for the search visualization.
    buttons = {
        "Main Menu": pygame.Rect(20, 20, 140, 45),
        "Start Search": pygame.Rect(180, 20, 140, 45),
        "New Array": pygame.Rect(340, 20, 140, 45),
        "Reset": pygame.Rect(500, 20, 120, 45)
    }

    colors = {
        "Main Menu": (255, 100, 100),
        "Start Search": (100, 255, 100),
        "New Array": (180, 180, 180),
        "Reset": (200, 200, 200)
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))
    return buttons


# --- LINEAR SEARCH MODULE ---

def linear_search_module(screen, clock):

    #Visualizes Linear Search with Comparison Counter and Keyboard Input.

    font = pygame.font.SysFont(None, 28)
    small_font = pygame.font.SysFont(None, 22)

    # Data Setup
    import random
    array = [random.randint(10, 99) for _ in range(10)]

    # Search State
    target_input = ""
    target_to_find = None
    current_index = -1
    comparisons = 0
    found_at = -1
    searching = False
    message = "Type a number and press Enter, then click 'Start Search'"

    running = True
    while running:
        screen.fill((220, 220, 240))
        buttons = draw_buttons(screen, font)

        # 1. KEYBOARD INPUT UI
        input_rect = pygame.Rect(20, 80, 200, 40)
        pygame.draw.rect(screen, (255, 255, 255), input_rect)
        pygame.draw.rect(screen, (0, 0, 0), input_rect, 2)

        input_label = small_font.render(f"Target: {target_input}", True, (0, 0, 0))
        screen.blit(input_label, (input_rect.x + 10, input_rect.y + 10))

        # 2. STATUS & COUNTER
        screen.blit(font.render(f"Status: {message}", True, (50, 50, 50)), (20, 130))
        screen.blit(font.render(f"Comparisons: {comparisons}", True, (200, 50, 50)), (20, 165))

        # 3. DRAW ARRAY CELLS
        for i, val in enumerate(array):
            rect = pygame.Rect(50 + (i * 55), 250, 50, 50)

            # Coloring Logic
            color = (255, 255, 255)  # Default
            if i == current_index:
                color = (255, 255, 0)  # Yellow for "Checking"
            if i == found_at:
                color = (0, 255, 0)  # Green for "Found"
            elif searching and i < current_index:
                color = (255, 200, 200)  # Light red for "Passed"

            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)

            val_txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(val_txt, (rect.x + 12, rect.y + 15))

            # Index Label
            idx_txt = small_font.render(f"[{i}]", True, (100, 100, 100))
            screen.blit(idx_txt, (rect.x + 15, rect.y + 55))

        # 4. SEARCH LOGIC
        if searching and current_index < len(array):
            pygame.time.delay(500)  # Slow down so the user can see the steps
            comparisons += 1
            if array[current_index] == target_to_find:
                found_at = current_index
                searching = False
                message = f"Found {target_to_find} at index {found_at}!"
            else:
                current_index += 1
                if current_index >= len(array):
                    searching = False
                    message = f"{target_to_find} not in array."

        # 5. EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # Keyboard Input Handling
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    target_input = target_input[:-1]
                elif event.key == pygame.K_RETURN:
                    if target_input.isdigit():
                        target_to_find = int(target_input)
                        message = f"Target set to {target_to_find}. Click 'Start Search'."
                else:
                    if event.unicode.isdigit() and len(target_input) < 2:
                        target_input += event.unicode

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                elif buttons["Start Search"].collidepoint(mx, my):
                    if target_to_find is not None:
                        current_index = 0
                        comparisons = 0
                        found_at = -1
                        searching = True
                        message = f"Searching for {target_to_find}..."
                    else:
                        message = "Error: Type a number first!"

                elif buttons["New Array"].collidepoint(mx, my):
                    array = [random.randint(10, 99) for _ in range(10)]
                    current_index = -1
                    comparisons = 0
                    found_at = -1
                    searching = False
                    message = "New array generated."

                elif buttons["Reset"].collidepoint(mx, my):
                    target_input = ""
                    target_to_find = None
                    current_index = -1
                    comparisons = 0
                    found_at = -1
                    searching = False
                    message = "Reset complete."

        pygame.display.flip()
        clock.tick(30)