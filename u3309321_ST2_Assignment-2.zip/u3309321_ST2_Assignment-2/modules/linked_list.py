# modules/linked_list.py


import pygame
import sys


# --- BUTTON UI HELPERS (Standardized) ---

def draw_buttons(screen, font):
    #Draws navigation and control buttons at the top of the screen.
    buttons = {
        "Main Menu": pygame.Rect(15, 20, 110, 45),
        "Append (End)": pygame.Rect(135, 20, 120, 45),
        "Insert at Idx 1": pygame.Rect(260, 20, 130, 45),
        "Delete at Idx 1": pygame.Rect(395, 20, 130, 45),
        "Reverse List": pygame.Rect(530, 20, 130, 45),
        "Reset": pygame.Rect(665, 20, 110, 45)
    }

    colors = {
        "Main Menu": (255, 100, 100),
        "Append (End)": (180, 180, 180),
        "Insert at Idx 1": (180, 180, 180),
        "Delete at Idx 1": (180, 180, 180),
        "Reverse List": (100, 200, 255),  # Blue to highlight the challenge feature
        "Reset": (100, 255, 100)
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))

    return buttons


# --- LINKED LIST ---

class Node:

    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    #Expanded for challenge requirements

    def __init__(self):
        self.head = None

    def append(self, value):
        if not self.head:
            self.head = Node(value)
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = Node(value)

    def insert_at(self, index, value):
        #Challenge Task: Insert at specific position
        new_node = Node(value)
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return

        current = self.head
        current_idx = 0
        while current and current_idx < index - 1:
            current = current.next
            current_idx += 1

        if current:
            new_node.next = current.next
            current.next = new_node

    def delete_at(self, index):
       #Challenge Task: Remove a node at a targeted position index.
        if not self.head:
            return
        if index == 0:
            self.head = self.head.next
            return

        current = self.head
        current_idx = 0
        while current and current.next and current_idx < index - 1:
            current = current.next
            current_idx += 1

        if current and current.next:
            current.next = current.next.next

    def reverse(self):
        #Challenge Task: Reverse the linked list
        prev = None
        current = self.head
        while current:
            next_node = current.next
            current.next = prev
            prev = current
            current = next_node
        self.head = prev


def draw_arrow(screen, start_pos, end_pos):
    #Draws a line with an arrowhead pointing to the next node.
    pygame.draw.line(screen, (0, 0, 0), start_pos, end_pos, 3)

    # Arrowhead math
    dx = end_pos[0] - start_pos[0]
    dy = end_pos[1] - start_pos[1]
    vec = pygame.math.Vector2(dx, dy)
    if vec.length() > 0:
        vec = vec.normalize()

    # Points for the triangle
    p1 = end_pos[0] - vec.x * 10 - vec.y * 5, end_pos[1] - vec.y * 10 + vec.x * 5
    p2 = end_pos[0] - vec.x * 10 + vec.y * 5, end_pos[1] - vec.y * 10 - vec.x * 5

    pygame.draw.polygon(screen, (0, 0, 0), [end_pos, p1, p2])


def linked_list_module(screen, clock):
    #Visualizes Linked List operations and the Reverse Challenge.
    font = pygame.font.SysFont(None, 24)
    header_font = pygame.font.SysFont(None, 32)

    ll = LinkedList()
    node_count = 0
    message = "Click 'Append' to add nodes."

    running = True
    while running:
        screen.fill((220, 220, 240))

        # 1. DRAW BUTTONS
        buttons = draw_buttons(screen, font)

        # 2. DRAW HEADER & STATUS
        screen.blit(header_font.render("Data Structure: Linked List", True, (50, 50, 150)), (20, 80))
        screen.blit(font.render(f"Status: {message}", True, (100, 100, 100)), (20, 115))

        # 3. VISUALIZE LINKED LIST (Nodes and Arrows)
        current = ll.head
        nodes_to_draw = []
        x, y = 100, 300

        while current:
            nodes_to_draw.append((current.value, x, y))
            x += 120  # Space between nodes
            current = current.next

        # Draw Arrows first so they sit behind the circles
        for i in range(len(nodes_to_draw) - 1):
            start_x, start_y = nodes_to_draw[i][1] + 25, nodes_to_draw[i][2]
            end_x, end_y = nodes_to_draw[i + 1][1] - 25, nodes_to_draw[i + 1][2]
            draw_arrow(screen, (start_x, start_y), (end_x, end_y))

        # Draw Node Circles
        for val, nx, ny in nodes_to_draw:
            pygame.draw.circle(screen, (100, 200, 255), (nx, ny), 25)
            pygame.draw.circle(screen, (0, 0, 0), (nx, ny), 25, 2)

            val_txt = font.render(str(val), True, (0, 0, 0))
            screen.blit(val_txt, (nx - val_txt.get_width() // 2, ny - val_txt.get_height() // 2))

        # 4. EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                elif buttons["Append (End)"].collidepoint(mx, my):
                    if node_count < 6:  # Keep it on screen
                        node_count += 1
                        val = node_count * 10
                        ll.append(val)
                        message = f"Appended {val} to the end."
                    else:
                        message = "List is getting too long for screen!"

                elif buttons["Insert at Idx 1"].collidepoint(mx, my):
                    if node_count < 6:
                        node_count += 1
                        val = 99
                        ll.insert_at(1, val)
                        message = f"Inserted {val} at Index 1."
                    else:
                        message = "List is getting too long for screen!"

                elif buttons["Delete at Idx 1"].collidepoint(mx, my):
                    if ll.head and ll.head.next:
                        ll.delete_at(1)
                        node_count = max(0, node_count - 1)
                        message = "Deleted node at Index 1."
                    elif ll.head:
                        message = "Index 1 does not exist (only Index 0 exists)!"
                    else:
                        message = "List is empty! Nothing to delete."

                elif buttons["Reverse List"].collidepoint(mx, my):
                    ll.reverse()
                    message = "List Reversed! Pointers updated."

                elif buttons["Reset"].collidepoint(mx, my):
                    ll = LinkedList()
                    node_count = 0
                    message = "List cleared."

        pygame.display.flip()
        clock.tick(30)