# modules/pathfinding_visualiser.py

import pygame
import sys
import collections


def draw_buttons(screen, font):
    #Standardized Buttons.
    buttons = {
        "Main Menu": pygame.Rect(10, 15, 120, 45),
        "Run Dijkstra": pygame.Rect(140, 15, 140, 45),
        "Clear Walls": pygame.Rect(290, 15, 130, 45),
        "Reset Grid": pygame.Rect(430, 15, 120, 45)
    }
    colors = {
        "Main Menu": (255, 100, 100),
        "Run Dijkstra": (180, 180, 180),
        "Clear Walls": (180, 180, 180),
        "Reset Grid": (100, 255, 100)
    }
    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))
    return buttons


def pathfinding_module(screen, clock):
    font = pygame.font.SysFont(None, 22)
    header_font = pygame.font.SysFont(None, 32)

    # 20 rows x 26 columns grid
    ROWS, COLS = 16, 24
    CELL_SIZE = 28
    START_X, START_Y = 60, 140

    start_cell = (2, 2)
    end_cell = (13, 21)
    walls = set()

    # Visualizer state variables
    visited = set()
    frontier = collections.deque([start_cell])
    parent_map = {start_cell: None}
    shortest_path = []

    searching = False
    complete = False
    message = "Left-Click drag to draw Walls. Right-Click to move Goal."

    running = True
    while running:
        screen.fill((220, 220, 240))
        buttons = draw_buttons(screen, font)

        screen.blit(header_font.render("Shortest Pathfinding (Dijkstra's Grid)", True, (50, 50, 150)), (20, 75))
        screen.blit(font.render(f"Status: {message}", True, (100, 100, 100)), (20, 108))

        # --- STEP-BY-STEP DIJKSTRA ANIMATION ---
        if searching and frontier:
            pygame.time.delay(15)  # Controls search step animation speed
            current = frontier.popleft()

            if current == end_cell:
                searching = False
                complete = True
                message = "Shortest Path Found! Backtracking layout."
                # Reconstruct path
                curr = end_cell
                while curr is not None:
                    shortest_path.append(curr)
                    curr = parent_map[curr]
            else:
                r, c = current
                # Check 4 cardinal neighbors
                for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < ROWS and 0 <= nc < COLS:
                        neighbor = (nr, nc)
                        if neighbor not in parent_map and neighbor not in walls:
                            parent_map[neighbor] = current
                            frontier.append(neighbor)
                            visited.add(neighbor)

        elif searching and not frontier:
            searching = False
            message = "No valid path available! Target blocked by walls."

        # --- DRAW GRID ---
        for r in range(ROWS):
            for c in range(COLS):
                rect = pygame.Rect(START_X + (c * CELL_SIZE), START_Y + (r * CELL_SIZE), CELL_SIZE, CELL_SIZE)

                # Base Color Default
                color = (255, 255, 255)
                if (r, c) == start_cell:
                    color = (0, 200, 0)  # Green Start
                elif (r, c) == end_cell:
                    color = (220, 0, 0)  # Red Goal
                elif (r, c) in shortest_path:
                    color = (255, 255, 0)  # Yellow Path
                elif (r, c) in walls:
                    color = (50, 50, 50)  # Charcoal Wall
                elif (r, c) in visited:
                    color = (175, 220, 255)  # Light Blue explored space

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, (200, 200, 200), rect, 1)

        # --- EVENT HANDLING ---
        m_left, _, m_right = pygame.mouse.get_pressed()
        mx, my = pygame.mouse.get_pos()

        grid_c = (mx - START_X) // CELL_SIZE
        grid_r = (my - START_Y) // CELL_SIZE
        inside_grid = (0 <= grid_r < ROWS and 0 <= grid_c < COLS)

        if inside_grid and not searching and not complete:
            target = (grid_r, grid_c)
            if m_left and target != start_cell and target != end_cell:
                walls.add(target)
            elif m_right and target != start_cell:
                end_cell = target

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False
                elif buttons["Run Dijkstra"].collidepoint(mx, my):
                    if not complete:
                        searching = True
                        message = "Computing Shortest Path..."
                elif buttons["Clear Walls"].collidepoint(mx, my):
                    walls.clear()
                    shortest_path = []
                    visited.clear()
                    frontier = collections.deque([start_cell])
                    parent_map = {start_cell: None}
                    complete = False
                    message = "Walls cleared."
                elif buttons["Reset Grid"].collidepoint(mx, my):
                    walls.clear()
                    shortest_path = []
                    visited.clear()
                    start_cell = (2, 2)
                    end_cell = (13, 21)
                    frontier = collections.deque([start_cell])
                    parent_map = {start_cell: None}
                    searching = False
                    complete = False
                    message = "Grid fully reset."

        pygame.display.flip()
        clock.tick(30)