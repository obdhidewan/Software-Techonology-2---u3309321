# modules/dp_visualiser.py

import pygame
import sys


# --- DYNAMIC PROGRAMMING LOGIC ---

def count_paths(rows, cols, obstacles=[]):
    #Grid Path Counting
    dp = [[0 for _ in range(cols)] for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if (i, j) in obstacles:
                dp[i][j] = 0
            elif i == 0 and j == 0:
                dp[i][j] = 1
            else:
                top = dp[i - 1][j] if i > 0 else 0
                left = dp[i][j - 1] if j > 0 else 0
                dp[i][j] = top + left
    return dp


def reconstruct_path(dp, rows, cols, obstacles=[]):
    path = []
    curr_r, curr_c = rows - 1, cols - 1
    if dp[curr_r][curr_c] == 0:
        return []
    while (curr_r, curr_c) != (0, 0):
        path.append((curr_r, curr_c))
        if curr_r > 0 and dp[curr_r - 1][curr_c] > 0:
            curr_r -= 1
        elif curr_c > 0 and dp[curr_r][curr_c - 1] > 0:
            curr_c -= 1
        else:
            break
    path.append((0, 0))
    return path


def calculate_coin_change(amount, coins):
    #Secondary DP Logic: Coin Change Minimum Coins
    # Initialize DP array
    dp = [999] * (amount + 1)
    dp[0] = 0

    # Track the choices to show steps
    history = []

    for i in range(1, amount + 1):
        for coin in coins:
            if i - coin >= 0:
                dp[i] = min(dp[i], dp[i - coin] + 1)
        # Deep copy state array at index i to animate step changes
        history.append(list(dp))
    return dp, history


# --- STANDARDIZED BUTTON INTERFACE ---

def draw_buttons(screen, font, current_mode):
    buttons = {
        "Main Menu": pygame.Rect(10, 15, 110, 45),
        "Toggle Mode": pygame.Rect(130, 15, 150, 45),
        "Animate": pygame.Rect(290, 15, 100, 45),
        "Action Button": pygame.Rect(400, 15, 130, 45),  # Contextual: Show Path or Reset
        "Reset Grid": pygame.Rect(540, 15, 110, 45)
    }
    colors = {
        "Main Menu": (255, 100, 100),
        "Toggle Mode": (100, 180, 255),
        "Animate": (180, 180, 180),
        "Action Button": (180, 180, 180),
        "Reset Grid": (100, 255, 100)
    }

    labels = {
        "Main Menu": "Main Menu",
        # --- FIXED SECTION: Dynamic label to indicate clear toggle actions ---
        "Toggle Mode": "Switch to Coin DP" if current_mode == "Grid Paths" else "Switch to Grid DP",
        "Animate": "Animate",
        "Action Button": "Show Path" if current_mode == "Grid Paths" else "Add Base Coin",
        "Reset Grid": "Reset"
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(labels[text], True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))
    return buttons


def puzzles_module(screen, clock):
    font = pygame.font.SysFont(None, 22)
    header_font = pygame.font.SysFont(None, 32)

    # State toggles
    mode = "Grid Paths"  # Switches between "Grid Paths" and "Coin Change"
    message = "Module ready."

    # --- 1. Grid Mode Variables ---
    rows, cols = 6, 6
    grid_size = 55
    start_x, start_y = 240, 210
    obstacles = [(1, 2), (2, 2), (3, 2)]
    dp_table = count_paths(rows, cols, obstacles)
    final_path = []
    revealed_cells = rows * cols
    show_path = False

    # --- 2. Coin Change Mode Variables ---
    target_amount = 12
    coins = [1, 3, 4]
    coin_dp, coin_history = calculate_coin_change(target_amount, coins)
    animated_step = target_amount  # Tracking index for animation rendering

    running = True
    while running:
        screen.fill((220, 220, 240))
        buttons = draw_buttons(screen, font, mode)

        # Header text & Strict Operational Status
        title_str = "Dynamic Programming: Grid Paths" if mode == "Grid Paths" else "DP Challenge: Minimum Coin Change"
        screen.blit(header_font.render(title_str, True, (50, 50, 150)), (20, 75))
        screen.blit(font.render(f"Status: {message}", True, (200, 50, 50)), (20, 108))

        # --- RENDER GRID PATHS MODE ---
        if mode == "Grid Paths":
            # --- DEDICATED INSTRUCTION TEXT Area ---
            instruction_color = (80, 80, 120)
            screen.blit(font.render("OBJECTIVE: Find total unique paths from top-left (START) to bottom-right (GOAL).", True, instruction_color), (20, 135))
            screen.blit(font.render("HOW TO PLAY: Click grid blocks to toggle obstacles, then click 'Animate'.", True, instruction_color), (20, 155))
            screen.blit(font.render("Click 'Show Path' to reconstruct and trace a valid layout course.", True, instruction_color), (20, 175))

            for i in range(rows):
                for j in range(cols):
                    rect = pygame.Rect(start_x + (j * grid_size), start_y + (i * grid_size), grid_size, grid_size)
                    color = (255, 255, 255)
                    if (i, j) in obstacles:
                        color = (100, 100, 100)
                    elif show_path and (i, j) in final_path:
                        color = (255, 255, 150)

                    pygame.draw.rect(screen, color, rect)
                    pygame.draw.rect(screen, (0, 0, 0), rect, 1)

                    cell_idx = i * cols + j
                    if cell_idx < revealed_cells and (i, j) not in obstacles:
                        val_txt = font.render(str(dp_table[i][j]), True, (0, 0, 0))
                        screen.blit(val_txt,
                                    (rect.centerx - val_txt.get_width() // 2, rect.centery - val_txt.get_height() // 2))

            screen.blit(font.render("START", True, (0, 150, 0)), (start_x - 60, start_y + 15))
            screen.blit(font.render("GOAL", True, (200, 0, 0)),
                        (start_x + (cols * grid_size) + 10, start_y + (rows - 1) * grid_size + 15))

            if revealed_cells < (rows * cols):
                pygame.time.delay(40)
                revealed_cells += 1

        # --- RENDER COIN CHANGE MODE (1D DP ARRAY VISUALIZATION) ---
        else:
            block_w, block_h = 50, 50
            start_cx = 70

            # --- DEDICATED INSTRUCTION TEXT AREA ---
            instruction_color = (80, 80, 120)
            screen.blit(font.render(f"Available Coins: {coins}", True, (0, 0, 0)), (20, 135))
            screen.blit(font.render("OBJECTIVE: Calculate the FEWEST total coins required to hit a specific sum amount.", True, instruction_color), (20, 160))
            screen.blit(font.render("HOW TO PLAY: Click 'Animate' to watch step matrix updates. Click 'Add Base Coin' to inject a 2c piece.", True, instruction_color), (20, 180))
            screen.blit(font.render("BOX LABEL = Minimum coins required  |  INDEX [x] = Target value amount", True, (70, 70, 70)), (20, 205))

            # Pushed blocks down to y=255 so they sit cleanly below instructions text
            for amt in range(target_amount + 1):
                rect = pygame.Rect(start_cx + (amt * (block_w + 4)), 255, block_w, block_h)

                # Highlight active cell currently processing
                color = (255, 255, 255)
                if amt == animated_step:
                    color = (255, 255, 150)  # Processing focus
                elif amt < animated_step:
                    color = (180, 255, 180)  # Verified state

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, (0, 0, 0), rect, 2)

                # Print array index header labels
                idx_lbl = font.render(f"[{amt}]", True, (120, 120, 120))
                screen.blit(idx_lbl, (rect.centerx - idx_lbl.get_width() // 2, rect.y - 20))

                # Fetch appropriate DP array string value based on current animated frame step
                if amt == 0:
                    val = 0
                elif amt <= animated_step:
                    val = coin_history[animated_step - 1][amt] if animated_step > 0 else 999
                else:
                    val = 999

                val_str = "INF" if val == 999 else str(val)
                val_txt = font.render(val_str, True, (0, 0, 0) if val_str != "INF" else (180, 180, 180))
                screen.blit(val_txt,
                            (rect.centerx - val_txt.get_width() // 2, rect.centery - val_txt.get_height() // 2))

            if animated_step < target_amount:
                pygame.time.delay(300)  # Slower delay for tracking equations easily
                animated_step += 1
                if animated_step == target_amount:
                    message = f"Min coins needed for {target_amount} is {coin_dp[target_amount]}."

        # --- HANDLE EVENT CLICKS ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                elif buttons["Toggle Mode"].collidepoint(mx, my):
                    mode = "Coin Change" if mode == "Grid Paths" else "Grid Paths"
                    message = "Switched problem module."
                    show_path = False
                    animated_step = target_amount
                    revealed_cells = rows * cols

                elif buttons["Animate"].collidepoint(mx, my):
                    if mode == "Grid Paths":
                        revealed_cells = 0
                        show_path = False
                        message = "Propagating 2D calculation array..."
                    else:
                        animated_step = 0
                        message = "Processing optimal subproblem coin combinations..."

                elif buttons["Action Button"].collidepoint(mx, my):
                    if mode == "Grid Paths":
                        final_path = reconstruct_path(dp_table, rows, cols, obstacles)
                        if not final_path:
                            message = "No path accessible! Target blocked by walls."
                        else:
                            show_path = True
                            message = "Valid path traced successfully."
                    else:
                        if 2 not in coins:
                            coins.append(2)
                            coins.sort()
                            coin_dp, coin_history = calculate_coin_change(target_amount, coins)
                            message = "Injected 2c coin denomination into table."

                elif buttons["Reset Grid"].collidepoint(mx, my):
                    if mode == "Grid Paths":
                        obstacles = []
                        dp_table = count_paths(rows, cols, obstacles)
                        revealed_cells = rows * cols
                        show_path = False
                    else:
                        coins = [1, 3, 4]
                        coin_dp, coin_history = calculate_coin_change(target_amount, coins)
                        animated_step = target_amount
                    message = "Reset completed."

                elif mode == "Grid Paths":
                    grid_c = (mx - start_x) // grid_size
                    grid_r = (my - start_y) // grid_size
                    if 0 <= grid_r < rows and 0 <= grid_c < cols:
                        target = (grid_r, grid_c)
                        if target in obstacles:
                            obstacles.remove(target)
                        else:
                            obstacles.append(target)
                        dp_table = count_paths(rows, cols, obstacles)
                        show_path = False

        pygame.display.flip()
        clock.tick(30)