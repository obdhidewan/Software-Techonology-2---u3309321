# modules/sorting_visualiser.py

import pygame
import random
import sys


# --- BUTTON UI HELPERS ---

def draw_buttons(screen, font):
    #Draws navigation and control buttons at the top of the screen.
    buttons = {
        "Main Menu": pygame.Rect(10, 15, 130, 45),
        "Bubble Sort": pygame.Rect(150, 15, 130, 45),
        "Selection": pygame.Rect(290, 15, 130, 45),
        "Merge Sort": pygame.Rect(430, 15, 130, 45),
        "Reset Array": pygame.Rect(650, 15, 130, 45)
    }

    # Standardized UI colors for consistency across modules
    colors = {
        "Main Menu": (255, 100, 100),  # Red
        "Bubble Sort": (180, 180, 180),  # Gray
        "Selection": (180, 180, 180),  # Gray
        "Merge Sort": (180, 180, 180),  # Gray
        "Reset Array": (100, 255, 100)  # Green
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        # Center the text inside the button
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))

    return buttons


# --- SORTING LOGIC & VISUALIZATION ---

def draw_array(screen, array, color_positions=None, action_text="Ready to Sort"):
    #Draws array bars below the button bar with standardized status messages.

    screen.fill((220, 220, 240))  # Standardized soft background

    # Redraw buttons so UI remains visible during the sorting animation
    font_small = pygame.font.SysFont(None, 22)
    draw_buttons(screen, font_small)

    WIDTH, HEIGHT = 800, 600
    bar_width = WIDTH // len(array)
    status_font = pygame.font.SysFont(None, 28)

    # UI Status & Legend (Coded by me: Positioned to avoid top buttons)
    title = status_font.render(f"Status: {action_text}", True, (50, 50, 150))
    screen.blit(title, (20, 80))

    legend = font_small.render("RED: Comparing | GREEN: Swapping | BLUE: Default", True, (100, 100, 100))
    screen.blit(legend, (20, 110))

    for i, val in enumerate(array):
        # Default bar color (Better colour palette)
        color = (100, 180, 255)

        # Highlights based on algorithm state
        if color_positions and 'compare' in color_positions and i in color_positions['compare']:
            color = (255, 100, 100)  # Red
        if color_positions and 'swap' in color_positions and i in color_positions['swap']:
            color = (100, 255, 100)  # Green

        # Draw bars starting from bottom, leaving room at the top for UI
        pygame.draw.rect(screen, color, (i * bar_width, HEIGHT - val - 20, bar_width - 2, val))

    pygame.display.flip()


def completed_delay(screen, array, algorithm_name):
    """Brief pause after finishing (Tutor's requirement)."""
    draw_array(screen, array, action_text=f"{algorithm_name} COMPLETE!")
    pygame.time.wait(1000)


# --- ALGORITHM VISUALIZATIONS ---

def bubble_sort_visualize(screen, array):
    n = len(array)
    for i in range(n):
        for j in range(0, n - i - 1):
            draw_array(screen, array, {'compare': [j, j + 1], 'swap': []}, "BUBBLE SORTING...")
            pygame.time.wait(20)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            if array[j] > array[j + 1]:
                array[j], array[j + 1] = array[j + 1], array[j]
                draw_array(screen, array, {'compare': [], 'swap': [j, j + 1]}, "BUBBLE SORTING...")
                pygame.time.wait(20)
    completed_delay(screen, array, "BUBBLE SORT")


def selection_sort_visualize(screen, array):
    n = len(array)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            draw_array(screen, array, {'compare': [min_idx, j], 'swap': []}, "SELECTION SORTING...")
            pygame.time.wait(20)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            if array[j] < array[min_idx]:
                min_idx = j

        array[i], array[min_idx] = array[min_idx], array[i]
        draw_array(screen, array, {'compare': [], 'swap': [i, min_idx]}, "SELECTION SORTING...")
        pygame.time.wait(20)
    completed_delay(screen, array, "SELECTION SORT")


def merge_sort_visualize(screen, array, l, r):
    if l < r:
        m = l + (r - l) // 2
        merge_sort_visualize(screen, array, l, m)
        merge_sort_visualize(screen, array, m + 1, r)
        merge(screen, array, l, m, r)

    if l == 0 and r == len(array) - 1:
        completed_delay(screen, array, "MERGE SORT")


def merge(screen, array, l, m, r):
    n1 = m - l + 1
    n2 = r - m
    L = [array[l + i] for i in range(n1)]
    R = [array[m + 1 + j] for j in range(n2)]
    i, j, k = 0, 0, l

    while i < n1 and j < n2:
        draw_array(screen, array, {'compare': [k], 'swap': []}, "MERGE SORTING...")
        if L[i] <= R[j]:
            array[k] = L[i]
            i += 1
        else:
            array[k] = R[j]
            j += 1
        draw_array(screen, array, {'compare': [], 'swap': [k]}, "MERGE SORTING...")
        pygame.time.wait(20)
        k += 1

    while i < n1:
        array[k] = L[i]
        draw_array(screen, array, {'compare': [], 'swap': [k]}, "MERGE SORTING...")
        i += 1
        k += 1

    while j < n2:
        array[k] = R[j]
        draw_array(screen, array, {'compare': [], 'swap': [k]}, "MERGE SORTING...")
        j += 1
        k += 1


# --- MODULE MAIN UI ---

def sorting_module(screen, clock):
    #Main loop for the Sorting Visualiser module.
    font_small = pygame.font.SysFont(None, 22)
    ARRAY_SIZE = 40
    array = [random.randint(50, 400) for _ in range(ARRAY_SIZE)]
    message = "Select a sorting algorithm."

    running = True
    while running:
        screen.fill((220, 220, 240))

        # 1. DRAW BUTTONS (Coded by me: Replaced scattered buttons with top bar)
        buttons = draw_buttons(screen, font_small)

        # 2. DRAW INITIAL STATE
        draw_array(screen, array, action_text=message)

        # 3. EVENT HANDLING (Coded by me: Button collisions)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False
                elif buttons["Bubble Sort"].collidepoint(mx, my):
                    bubble_sort_visualize(screen, array)
                    message = "Bubble Sort Finished."
                elif buttons["Selection"].collidepoint(mx, my):
                    selection_sort_visualize(screen, array)
                    message = "Selection Sort Finished."
                elif buttons["Merge Sort"].collidepoint(mx, my):
                    merge_sort_visualize(screen, array, 0, len(array) - 1)
                    message = "Merge Sort Finished."
                elif buttons["Reset Array"].collidepoint(mx, my):
                    array = [random.randint(50, 400) for _ in range(ARRAY_SIZE)]
                    message = "Array Randomized."

        pygame.display.flip()
        clock.tick(30)