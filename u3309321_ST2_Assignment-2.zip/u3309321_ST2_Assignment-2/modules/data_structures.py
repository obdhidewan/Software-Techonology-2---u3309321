# modules/data_structures.py

import pygame
import sys


# --- BUTTON UI HELPERS ---

def draw_buttons(screen, font, current_mode=None):
    #Draws navigation and control buttons at the top of the screen.
    buttons = {
        "Main Menu": pygame.Rect(20, 20, 140, 45),
        "Add Item": pygame.Rect(180, 20, 120, 45),
        "Remove Item": pygame.Rect(320, 20, 140, 45),
        "Toggle Mode": pygame.Rect(480, 20, 140, 45),
        "Reset": pygame.Rect(640, 20, 140, 45)
    }

    # Colors of standard application buttons
    colors = {
        "Main Menu": (255, 100, 100),  # Red
        "Add Item": (180, 180, 180),  # Gray
        "Remove Item": (180, 180, 180),  # Gray
        "Toggle Mode": (100, 180, 255),  # Blue highlight for the action toggle
        "Reset": (100, 255, 100)  # Green
    }

    labels = {
        "Main Menu": "Main Menu",
        "Add Item": "Add Item",
        "Remove Item": "Remove Item",
        # --- FIXED SECTION: Dynamic label to indicate clear toggle actions ---
        "Toggle Mode": "Switch to Queue" if current_mode == "STACK" else "Switch to Stack",
        "Reset": "Reset"
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)  # Button border
        txt_surf = font.render(labels[text], True, (0, 0, 0))
        # Center the text inside the button
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))

    return buttons


# --- WEEK 10 & 11: DATA STRUCTURES ---

def data_structures_module(screen, clock):

    #Visualizes Stack (LIFO) and Queue (FIFO) operations.
    #Includes Task 1.2 Challenge: Smooth Animations.

    font = pygame.font.SysFont(None, 24)
    header_font = pygame.font.SysFont(None, 32)

    # Visual items format: [value, current_x, current_y]
    visual_items = []

    mode = "STACK"  # Default mode
    message = "Click 'Add Item' to begin!"

    running = True
    while running:
        screen.fill((220, 220, 240))  # Soft background color for cleaner UI

        # 1. DRAW PERMANENT UI BUTTONS (Coded by me: Replaced Keyboard/Sidebar)
        buttons = draw_buttons(screen, font, mode)

        # 2. DRAW HEADER & STATUS
        screen.blit(header_font.render(f"Mode: {mode}", True, (50, 50, 150)), (20, 80))
        screen.blit(font.render(f"Status: {message}", True, (100, 100, 100)), (20, 115))

        # 3. VISUALIZE ITEMS (+ Smooth Animation Challenge)
        for i, item_data in enumerate(visual_items):
            item_val, curr_x, curr_y = item_data

            # Target position logic
            if mode == "STACK":
                target_x, target_y = 350, 500 - (i * 45)
                # Highlight "Top" (Last item)
                color = (255, 100, 100) if i == len(visual_items) - 1 else (100, 200, 255)
            else:
                target_x, target_y = 100 + (i * 110), 250
                # Highlight "Front" (First item)
                color = (255, 100, 100) if i == 0 else (100, 200, 255)

            # Interpolation for smooth sliding animation
            curr_x += (target_x - curr_x) * 0.2
            curr_y += (target_y - curr_y) * 0.2
            visual_items[i][1] = curr_x
            visual_items[i][2] = curr_y

            rect = pygame.Rect(curr_x, curr_y, 100, 40)
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (0, 0, 0), rect, 2)

            val_txt = font.render(str(item_val), True, (0, 0, 0))
            screen.blit(val_txt, (rect.x + 40, rect.y + 10))

        # 4. HANDLE EVENTS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                # MAIN MENU
                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                # TOGGLE MODE (Stack/Queue)
                elif buttons["Toggle Mode"].collidepoint(mx, my):
                    mode = "QUEUE" if mode == "STACK" else "STACK"
                    message = f"Switched to {mode} mode."

                # ADD ITEM ( Push for Stack / Enqueue for Queue)
                elif buttons["Add Item"].collidepoint(mx, my):
                    if len(visual_items) < 10:
                        new_val = (len(visual_items) + 1) * 10
                        # Start block at the top of the screen for "entering" effect
                        visual_items.append([new_val, 350, -50])
                        message = f"Added {new_val} to the {mode}."
                    else:
                        message = "Structure is full!"

                # REMOVE ITEM (Pop for Stack / Dequeue for Queue)
                elif buttons["Remove Item"].collidepoint(mx, my):
                    if visual_items:
                        if mode == "STACK":
                            removed = visual_items.pop()  # LIFO: Remove last
                        else:
                            removed = visual_items.pop(0)  # FIFO: Remove first
                        message = f"Removed {removed[0]} from the {mode}."
                    else:
                        message = f"The {mode} is already empty!"

                # RESET
                elif buttons["Reset"].collidepoint(mx, my):
                    visual_items = []
                    message = "Cleared all data."

        pygame.display.flip()
        clock.tick(60)  # Increased tick rate for smoother animations