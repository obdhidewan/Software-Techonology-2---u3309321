# modules/graph_visualiser.py

import pygame
import collections
import sys


# --- BUTTON UI HELPERS ---

def draw_buttons(screen, font):
    #Draws navigation and control buttons at the top of the screen.
    buttons = {
        "Main Menu": pygame.Rect(20, 20, 140, 45),
        "Toggle BFS/DFS": pygame.Rect(180, 20, 150, 45),
        "Reset Graph": pygame.Rect(350, 20, 140, 45)
    }

    # Colors mimicking the standardized UI style
    colors = {
        "Main Menu": (255, 100, 100),  # Red
        "Toggle BFS/DFS": (180, 180, 180),  # Gray
        "Reset Graph": (100, 255, 100)  # Green
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)  # Button border
        txt_surf = font.render(text, True, (0, 0, 0))
        # Center the text inside the button
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))

    return buttons


# --- GRAPHS MODULE ---

def graphs_module(screen, clock):

    #Visualizes BFS and DFS traversals on a graph.

    font = pygame.font.SysFont(None, 24)
    header_font = pygame.font.SysFont(None, 32)

    # Coordinates
    nodes_pos = {
        'A': (200, 300),
        'B': (400, 230),
        'C': (200, 450),
        'D': (400, 520),
        'E': (550, 375),
        'F': (720, 375)
    }
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'D'],
        'D': ['B', 'C', 'E'],
        'E': ['B', 'D', 'F'],
        'F': ['E']
    }

    # State variables for Task 3.1 UI
    visited = []
    frontier = []
    searching = False
    traversal_mode = "BFS"
    status_text = "Select a node to start search"

    running = True
    while running:
        screen.fill((220, 220, 240))  # better background color

        # 1. DRAW UI ELEMENTS
        buttons = draw_buttons(screen, font)

        # DRAW HEADER & STATUS (Positioned to avoid buttons)
        title_msg = f"Graph Traversal: {traversal_mode}"
        screen.blit(header_font.render(title_msg, True, (50, 50, 150)), (20, 80))
        screen.blit(font.render(f"Status: {status_text}", True, (100, 100, 100)), (20, 110))

        # 2. DRAW TRAVERSAL ORDER (Challenge Requirement)
        path_str = " -> ".join(visited)
        path_txt = font.render(f"Path: {path_str}", True, (0, 0, 255))
        # Updated Y coordinate to 560 to sit at the bottom
        screen.blit(path_txt, (screen.get_width() // 2 - path_txt.get_width() // 2, 560))

        # 3. DRAW EDGES
        for start_node, neighbors in graph.items():
            for end_node in neighbors:
                pygame.draw.line(screen, (150, 150, 150), nodes_pos[start_node], nodes_pos[end_node], 2)

        # 4. DRAW NODES
        for node, pos in nodes_pos.items():
            color = (255, 255, 255)
            if node in visited:
                color = (100, 255, 100)  # Visited (Green)
            elif node in frontier:
                color = (255, 255, 100)  # In Frontier (Yellow)

            pygame.draw.circle(screen, color, pos, 25)
            pygame.draw.circle(screen, (0, 0, 0), pos, 25, 2)
            node_txt = font.render(node, True, (0, 0, 0))
            screen.blit(node_txt, (pos[0] - 8, pos[1] - 10))

        # 5. HANDLE EVENTS
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                # Check Button Collisions
                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                elif buttons["Toggle BFS/DFS"].collidepoint(mx, my):
                    if not searching:
                        traversal_mode = "DFS" if traversal_mode == "BFS" else "BFS"
                        status_text = f"Switched to {traversal_mode}"

                elif buttons["Reset Graph"].collidepoint(mx, my):
                    visited, frontier, searching = [], [], False
                    status_text = "Graph Reset."

                # Check Node Clicks to start search
                else:
                    for node, pos in nodes_pos.items():
                        dist = ((mx - pos[0]) ** 2 + (my - pos[1]) ** 2) ** 0.5
                        if dist < 25:
                            visited, frontier = [], [node]
                            searching = True
                            status_text = f"Searching {traversal_mode}..."

        # 6. TRAVERSAL ANIMATION
        if searching and frontier:
            pygame.time.delay(600)  # Slow down for visualization

            # BFS = FIFO (pop first) | DFS = LIFO (pop last)
            current = frontier.pop(0) if traversal_mode == "BFS" else frontier.pop()

            if current not in visited:
                visited.append(current)
                for neighbor in graph[current]:
                    if neighbor not in visited and neighbor not in frontier:
                        frontier.append(neighbor)

        elif searching and not frontier:
            searching = False
            status_text = f"{traversal_mode} Complete!"

        pygame.display.flip()
        clock.tick(30)