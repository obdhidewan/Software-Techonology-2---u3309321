# modules/bst_visualiser.py
import pygame
import sys
import time
import random

# --- BUTTON UI HELPERS ---
def draw_buttons(screen, font):
    buttons = {
        "Main Menu": pygame.Rect(20, 20, 120, 45),
        "Insert Node": pygame.Rect(150, 20, 120, 45),
        "In-order": pygame.Rect(280, 20, 100, 45),
        "Pre-order": pygame.Rect(390, 20, 110, 45),
        "Post-order": pygame.Rect(510, 20, 110, 45),
        "Reset": pygame.Rect(630, 20, 100, 45)
    }
    colors = {
        "Main Menu": (255, 100, 100), "Insert Node": (180, 180, 180),
        "In-order": (100, 255, 100), "Pre-order": (100, 255, 100),
        "Post-order": (100, 255, 100), "Reset": (200, 200, 200)
    }
    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))
    return buttons

# --- BST LOGIC ---
class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None
        self.traversal_path = []

    def insert(self, value):
        if not self.root: self.root = BSTNode(value)
        else: self._insert_recursive(self.root, value)

    def _insert_recursive(self, node, value):
        if value < node.value:
            if node.left is None: node.left = BSTNode(value)
            else: self._insert_recursive(node.left, value)
        elif value > node.value:
            if node.right is None: node.right = BSTNode(value)
            else: self._insert_recursive(node.right, value)

    def get_inorder(self, node):
        if node:
            self.get_inorder(node.left)
            self.traversal_path.append(node.value)
            self.get_inorder(node.right)

    def get_preorder(self, node):
        if node:
            self.traversal_path.append(node.value)
            self.get_preorder(node.left)
            self.get_preorder(node.right)

    def get_postorder(self, node):
        if node:
            self.get_postorder(node.left)
            self.get_postorder(node.right)
            self.traversal_path.append(node.value)

# --- VISUALIZATION ---
def draw_tree(screen, node, x, y, x_offset, font, highlighted_val=None):
    if node:
        color = (255, 255, 0) if node.value == highlighted_val else (100, 200, 255)
        if node.left:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x - x_offset, y + 80), 2)
            draw_tree(screen, node.left, x - x_offset, y + 80, x_offset // 1.8, font, highlighted_val)
        if node.right:
            pygame.draw.line(screen, (0, 0, 0), (x, y), (x + x_offset, y + 80), 2)
            draw_tree(screen, node.right, x + x_offset, y + 80, x_offset // 1.8, font, highlighted_val)
        pygame.draw.circle(screen, color, (x, y), 22)
        pygame.draw.circle(screen, (0, 0, 0), (x, y), 22, 2)
        val_txt = font.render(str(node.value), True, (0, 0, 0))
        screen.blit(val_txt, (x - val_txt.get_width() // 2, y - val_txt.get_height() // 2))

def bst_module(screen, clock):
    font = pygame.font.SysFont(None, 24)
    tree = BST()
    message = "Click 'Insert' to build tree"
    highlighted_node = None
    animation_queue = []
    last_update = time.time()

    running = True
    while running:
        screen.fill((220, 220, 240))
        buttons = draw_buttons(screen, font)
        draw_tree(screen, tree.root, 400, 180, 180, font, highlighted_node)

        if animation_queue and time.time() - last_update > 0.8:
            highlighted_node = animation_queue.pop(0)
            last_update = time.time()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                if buttons["Main Menu"].collidepoint(mx, my): running = False
                elif buttons["Insert Node"].collidepoint(mx, my):
                    val = random.randint(10, 99)
                    tree.insert(val)
                    message = f"Inserted {val}"
                elif buttons["In-order"].collidepoint(mx, my):
                    tree.traversal_path = []; tree.get_inorder(tree.root)
                    animation_queue = list(tree.traversal_path)
                elif buttons["Pre-order"].collidepoint(mx, my):
                    tree.traversal_path = []; tree.get_preorder(tree.root)
                    animation_queue = list(tree.traversal_path)
                elif buttons["Post-order"].collidepoint(mx, my):
                    tree.traversal_path = []; tree.get_postorder(tree.root)
                    animation_queue = list(tree.traversal_path)
                elif buttons["Reset"].collidepoint(mx, my):
                    tree = BST(); animation_queue = []; highlighted_node = None

        pygame.display.flip()
        clock.tick(30)