# modules/heap_visualiser.py

import pygame
import random
import sys


# --- HEAP LOGIC ---

class MinHeap:
    def __init__(self):
        # The heap stores tuples: (priority, description)
        self.heap = []

    def insert(self, priority, description):
        self.heap.append((priority, description))
        self._bubble_up(len(self.heap) - 1)

    def _bubble_up(self, index):
        #Moves element up to restore min-heap property.
        parent = (index - 1) // 2
        if index > 0 and self.heap[index][0] < self.heap[parent][0]:
            self.heap[index], self.heap[parent] = self.heap[parent], self.heap[index]
            self._bubble_up(parent)

    def extract_min(self):
        #Logic to pop the earliest event (Week 12 Task 3.2).
        if not self.heap:
            return None
        if len(self.heap) == 1:
            return self.heap.pop()

        root = self.heap[0]
        self.heap[0] = self.heap.pop()
        self._bubble_down(0)
        return root

    def _bubble_down(self, index):
        #Standard sink logic to restore min-heap after extraction.
        smallest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < len(self.heap) and self.heap[left][0] < self.heap[smallest][0]:
            smallest = left
        if right < len(self.heap) and self.heap[right][0] < self.heap[smallest][0]:
            smallest = right

        if smallest != index:
            self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
            self._bubble_down(smallest)


# --- BUTTON UI HELPERS ---

def draw_buttons(screen, font):
    #Draws navigation and control buttons at the top of the screen.
    buttons = {
        "Main Menu": pygame.Rect(20, 20, 140, 45),
        "Insert Event": pygame.Rect(180, 20, 140, 45),
        "Process Event": pygame.Rect(340, 20, 140, 45),
        "Reset Heap": pygame.Rect(640, 20, 140, 45)
    }

    # Standardized UI colors
    colors = {
        "Main Menu": (255, 100, 100),  # Red
        "Insert Event": (180, 180, 180),  # Gray
        "Process Event": (180, 180, 180),  # Gray
        "Reset Heap": (100, 255, 100)  # Green
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, colors[text], rect)
        pygame.draw.rect(screen, (0, 0, 0), rect, 2)
        txt_surf = font.render(text, True, (0, 0, 0))
        screen.blit(txt_surf, (rect.x + (rect.width - txt_surf.get_width()) // 2,
                               rect.y + (rect.height - txt_surf.get_height()) // 2))

    return buttons


# --- MODULE VISUALIZATION ---

def heap_module(screen, clock):
    #Visualizes an Event Simulator using a Min-Heap.
    font = pygame.font.SysFont(None, 24)
    header_font = pygame.font.SysFont(None, 32)
    min_heap = MinHeap()
    WIDTH = 800

    # Tutorial data for simulation
    event_pool = [
        "Server Maintenance", "Database Backup", "Security Patch",
        "User Ticket #402", "Log Rotation", "Cache Clear"
    ]

    current_event = None
    message = "Click 'Insert Event' to add to the queue."

    running = True
    while running:
        screen.fill((220, 220, 240))  # Standardized background

        # 1. DRAW UI ELEMENTS
        buttons = draw_buttons(screen, font)

        # HEADER & STATUS
        screen.blit(header_font.render("Event Priority Simulator (Min-Heap)", True, (50, 50, 150)), (20, 80))
        screen.blit(font.render(f"Status: {message}", True, (100, 100, 100)), (20, 110))

        if current_event:
            status = f"Last Processed: {current_event[1]} (Priority: {current_event[0]})"
            screen.blit(font.render(status, True, (200, 0, 0)), (20, 135))

        # 2. DYNAMICALLY CENTERED HEAP TREE
        for i, (priority, desc) in enumerate(min_heap.heap):
            # Calculate levels and positions
            level = i.bit_length() - 1 if i > 0 else 0
            num_nodes_at_level = 2 ** level
            index_in_level = i - (2 ** level - 1) if i > 0 else 0

            x_spacing = WIDTH / (num_nodes_at_level + 1)
            x = (index_in_level + 1) * x_spacing
            y = 250 + (level * 90)  # Pushed down to clear buttons/header

            # Connections to children
            left_child = 2 * i + 1
            right_child = 2 * i + 2
            for child_idx in [left_child, right_child]:
                if child_idx < len(min_heap.heap):
                    c_level = child_idx.bit_length() - 1
                    c_num_nodes = 2 ** c_level
                    c_index_in_level = child_idx - (2 ** c_level - 1)
                    c_x_spacing = WIDTH / (c_num_nodes + 1)

                    cx = (c_index_in_level + 1) * c_x_spacing
                    cy = 250 + (c_level * 90)
                    pygame.draw.line(screen, (150, 150, 150), (int(x), int(y)), (int(cx), int(cy)), 2)

            # Draw Node (Coded by me: Highlight logic)
            pygame.draw.circle(screen, (255, 255, 255), (int(x), int(y)), 22)
            pygame.draw.circle(screen, (0, 0, 0), (int(x), int(y)), 22, 2)
            val_txt = font.render(str(priority), True, (0, 0, 0))
            screen.blit(val_txt, (int(x) - val_txt.get_width() // 2, int(y) - val_txt.get_height() // 2))

            # Event description for higher levels
            if level < 2:
                desc_txt = font.render(desc, True, (80, 80, 80))
                screen.blit(desc_txt, (int(x) - desc_txt.get_width() // 2, int(y) + 25))

        # 3. EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                # Main Menu
                if buttons["Main Menu"].collidepoint(mx, my):
                    running = False

                # Insert Logic
                elif buttons["Insert Event"].collidepoint(mx, my):
                    prio = random.randint(1, 10)
                    desc = random.choice(event_pool)
                    min_heap.insert(prio, desc)
                    message = f"Added: {desc} (Priority: {prio})"

                # Process Logic
                elif buttons["Process Event"].collidepoint(mx, my):
                    if min_heap.heap:
                        current_event = min_heap.extract_min()
                        message = f"Processing: {current_event[1]}"
                    else:
                        current_event = None
                        message = "No events left to process!"

                # Reset
                elif buttons["Reset Heap"].collidepoint(mx, my):
                    min_heap = MinHeap()
                    current_event = None
                    message = "Simulator Reset."

        pygame.display.flip()
        clock.tick(30)