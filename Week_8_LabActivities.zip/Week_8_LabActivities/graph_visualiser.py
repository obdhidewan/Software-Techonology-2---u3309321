from graph import Graph
import tkinter as tk
import math  # Needed for coordinate calculations


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()

        # Window title
        self.title("Graph Visualizer")

        # Store graph instance
        self.graph = graph

        # Canvas for drawing graph
        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack()

        # Dictionary to store vertex positions for edge drawing
        self.vertex_positions = {}

        # Draw the graph initially
        self.draw_graph()

    def draw_graph(self):
        # Clear previous drawings
        self.canvas.delete("all")

        radius = 20        # Radius of each vertex circle
        spacing = 100      # Distance from center

        # Number of vertices
        n = len(self.graph.graph)

        # Angle gap between vertices in a circular layout
        angle_gap = 360 / n if n else 0

        # Center of the canvas
        center_x, center_y = 200, 200

        # -------- Draw vertices --------
        for i, v in enumerate(self.graph.graph):

            # Calculate angle for circular placement
            angle = i * angle_gap

            # Convert polar coordinates to Cartesian coordinates
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))

            # Store position
            self.vertex_positions[v] = (x, y)

            # Draw vertex (circle)
            self.canvas.create_oval(
                x - radius, y - radius,
                x + radius, y + radius,
                fill='lightblue'
            )

            # Draw vertex label
            self.canvas.create_text(x, y, text=v)

        # -------- Draw edges --------
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]

            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                # Draw edge (arrow if directed graph)
                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None
                )

                # Display weight if graph is weighted
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')

                    # Midpoint of the edge
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2

                    # Draw weight label
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")


if __name__ == "__main__":
    # Create a weighted directed graph
    g = Graph(directed=True, weighted=True)

    # Add vertices
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')

    # Add weighted edges
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    # Launch visualizer
    app = GraphVisualizer(g)
    app.mainloop()