#===graph.py===

class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)

                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")


    # ===== ADDED METHODS for Task 1 =====

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:

            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)

                if self.weighted:
                    self.weights.pop((vertex1, vertex2), None)

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)

                    if self.weighted:
                        self.weights.pop((vertex2, vertex1), None)
        else:
            print("One or both vertices not found in graph.")


    def remove_vertex(self, vertex):
        if vertex in self.graph:

            # remove edges pointing to this vertex
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

                    if self.weighted:
                        self.weights.pop((v, vertex), None)

            # remove the vertex itself
            del self.graph[vertex]

            # clean up weights
            if self.weighted:
                keys_to_delete = []
                for key in self.weights:
                    if vertex in key:
                        keys_to_delete.append(key)

                for key in keys_to_delete:
                    del self.weights[key]
        else:
            print("Vertex not found.")


    def print_graph(self):
        for vertex in self.graph:
            print(vertex, "->", self.graph[vertex])

        if self.weighted:
            print("Weights:", self.weights)


    # ===== BFS for Task 2 =====
    def bfs(self, start_vertex):
        visited = []
        queue = []

        if start_vertex not in self.graph:
            print("Start vertex not found.")
            return visited

        queue.append(start_vertex)
        visited.append(start_vertex)

        while queue:
            vertex = queue.pop(0)

            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    visited.append(neighbour)
                    queue.append(neighbour)

        return visited

    # ===== DFS for Task 3 =====
    def dfs(self, start_vertex):
        visited = []
        stack = []

        if start_vertex not in self.graph:
            print("Start vertex not found.")
            return visited

        stack.append(start_vertex)

        while stack:
            vertex = stack.pop()

            if vertex not in visited:
                visited.append(vertex)

                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited

    # ===== Cycle Detection for Undirected Graph (Task 4) =====
    def has_undirected_cycle(self):
        visited = set()

        def dfs(vertex, parent):
            visited.add(vertex)

            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    if dfs(neighbour, vertex):
                        return True
                elif neighbour != parent:
                    return True

            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True

        return False