from graph import Graph
import time
import random


def benchmark_graph_operations(num_vertices, num_edges):

    # Create a new graph instance
    g = Graph()

    # ===== Measure vertex insertion time =====
    start_time = time.time()

    # Add vertices to the graph
    for i in range(num_vertices):
        g.add_vertex(str(i))

    vertex_time = time.time()

    print(f"Added {num_vertices} vertices in {vertex_time - start_time:.4f} seconds")

    # ===== Measure edge insertion time =====
    edges_added = 0

    for _ in range(num_edges):
        # Randomly select two vertices
        v1 = str(random.randint(0, num_vertices - 1))
        v2 = str(random.randint(0, num_vertices - 1))

        # Avoid self-loops
        if v1 != v2:
            g.add_edge(v1, v2)
            edges_added += 1

    edge_time = time.time()

    print(f"Added {edges_added} edges in {edge_time - vertex_time:.4f} seconds")

    # ===== Measure BFS traversal time =====
    if '0' in g.graph:
        bfs_start = time.time()

        # Perform BFS starting from vertex '0'
        g.bfs('0')

        bfs_time = time.time()

        print(f"BFS completed in {bfs_time - bfs_start:.4f} seconds")
    else:
        print("Vertex '0' not found for BFS")

    # ===== Measure DFS traversal time =====
    if '0' in g.graph:
        dfs_start = time.time()

        # Perform DFS starting from vertex '0'
        g.dfs('0')

        dfs_time = time.time()

        print(f"DFS completed in {dfs_time - dfs_start:.4f} seconds")


# ===== Run benchmarks for different graph sizes =====
if __name__ == "__main__":

    print("\n--- Benchmark with 10 vertices ---")
    benchmark_graph_operations(10, 20)

    print("\n--- Benchmark with 100 vertices ---")
    benchmark_graph_operations(100, 300)

    print("\n--- Benchmark with 1000 vertices ---")
    benchmark_graph_operations(1000, 3000)