#===graph_tester.py===
from graph import Graph

# ----- Undirected graph -----
print("Undirected Graph")

g = Graph()

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

# Add edges
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

# Display graph
g.print_graph()
print()


# ----- Directed graph -----
print("Directed Graph")

g = Graph(directed=True)

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

# Add edges
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

# Display graph
g.print_graph()
print()


# ----- Weighted undirected graph -----
print("Weighted Undirected Graph")

g = Graph(weighted=True)

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

# Add weighted edges
g.add_edge('A', 'B', 10)
g.add_edge('B', 'C', 20)
g.add_edge('C', 'D', 30)

# Display graph with weights
g.print_graph()
print()


# ----- Weighted directed graph -----
print("Weighted Directed Graph")

g = Graph(weighted=True, directed=True)

# Add vertices
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

# Add weighted edges
g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 50)

# Display graph with weights
g.print_graph()


# ----- Removal test -----
print()
print("Removal Test")

removal_test = Graph()

# Add vertices
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

# Add edges
removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')

print("Original graph:")
removal_test.print_graph()

print("\nAfter removing edge A-B:")
removal_test.remove_edge('A', 'B')
removal_test.print_graph()

print("\nAfter removing vertex C:")
removal_test.remove_vertex('C')
removal_test.print_graph()

print()


# ===== Task 2: BFS =====
print("BFS Test")

# Create a small graph for BFS
g = Graph()

g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

# A → B → C with extra connections
g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')

g.print_graph()

# Given code from tutor
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)