import timeit
import random

# ----------------------------
# LINEAR SEARCH
# ----------------------------
def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i
    return -1

# ----------------------------
# BINARY SEARCH
# ----------------------------
def binary_search(array, target):
    left = 0
    right = len(array) - 1
    mid = (left + right) // 2
    while left <= right:
        if array[mid] == target:
            return mid
        elif target > array[mid]:
            left = mid + 1
        else:
            right = mid - 1
        mid = (left + right) // 2
    return -1

# ----------------------------
# BUBBLE SORT
# ----------------------------
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr

# ----------------------------
# INSERTION SORT
# ----------------------------
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr

# ----------------------------
# COMBINATIONS FOR TASK 4
# ----------------------------
def insertion_linear(array, target):
    return linear_search(insertion_sort(array.copy()), target)

def bubble_linear(array, target):
    return linear_search(bubble_sort(array.copy()), target)

def insertion_binary(array, target):
    return binary_search(insertion_sort(array.copy()), target)

def bubble_binary(array, target):
    return binary_search(bubble_sort(array.copy()), target)

# ----------------------------
# TESTING FOR DIFFERENT DATA SIZES
# ----------------------------
data_sizes = [5, 10, 100, 1000, 10000]

print("\n--- TASK 4: Sorting + Searching Combinations ---\n")

for size in data_sizes:
    test_list = [random.randint(1, size*10) for _ in range(size)]
    target = random.choice(test_list)

    print(f"Data size: {size}")

    t1 = timeit.timeit(lambda: insertion_linear(test_list, target), number=1)
    t2 = timeit.timeit(lambda: bubble_linear(test_list, target), number=1)
    t3 = timeit.timeit(lambda: insertion_binary(test_list, target), number=1)
    t4 = timeit.timeit(lambda: bubble_binary(test_list, target), number=1)

    print(f"Insertion Sort + Linear Search: {t1:.6f} s")
    print(f"Bubble Sort + Linear Search:    {t2:.6f} s")
    print(f"Insertion Sort + Binary Search: {t3:.6f} s")
    print(f"Bubble Sort + Binary Search:    {t4:.6f} s\n")

# ----------------------------
# COMMENTARY:
# - Insertion Sort + Binary Search is usually the fastest among combinations.
# - Bubble Sort + Linear Search is typically the slowest, especially for large data sizes.
# - Sorting dominates runtime for large lists, so more efficient sorting (Insertion vs Bubble) matters.
# ----------------------------