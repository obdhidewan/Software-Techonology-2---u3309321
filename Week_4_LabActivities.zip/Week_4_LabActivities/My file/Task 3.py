import timeit
import random

# ------------------------------------------------------------
# INTRODUCTION
# Now that we've gotten some background on searching algorithms, let's
# try and implement some basic ones. First, we'll try the most basic of all:
# linear search. Despite its simplicity, linear search is actually the
# algorithm that Python lists use when we check membership with the 'in'
# keyword.
#
# Note that with the Python data structures we're using here, the function
# of these algorithms is not necessary (as the Python structures already
# implement searching, sorting, etc.). We are doing it for the sake of
# learning the theory. In practice, it is recommended to use the
# built-in searching functions!
# ------------------------------------------------------------

# --------------------
# LINEAR SEARCH
# --------------------
# Linear search involves sequentially checking every element
# in a collection until the desired value is found.
def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i
    return -1

# Example test for linear search
test = range(1000000)
print(linear_search(test, 99999))  # Should find the target
print(linear_search(test, -999))   # Should not find the target


# --------------------
# BINARY SEARCH
# --------------------
# Binary search can be more efficient than linear search, but requires
# sorted data. It does not guarantee returning the first occurrence
# if there are duplicates.

def binary_search(array, target):
    left = 0
    right = len(array) - 1
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target:
            return mid
        elif target > array[mid]:
            left = mid + 1
        else:
            right = mid - 1
        mid = int((left + right)/2)
    return -1

# Example test for binary search
test = [1, 1, 1, 2, 3, 6, 9, 19, 555]
print(binary_search(test, 1))
print(binary_search(test, 555))


# --------------------
# COMPARING LINEAR AND BINARY SEARCH
# --------------------
# Generate a sorted list of integers for testing
sorted_list = list(range(1000000))
target = random.randint(0, 999999)  # Random target value

linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

print(f"Linear search execution time: {linear_time:.6f} seconds")
print(f"Binary search execution time: {binary_time:.6f} seconds")

# As we can see, for sorted data, binary search is orders of magnitude faster than linear search.


# ------------------------------------------------------------
# SORTING ALGORITHMS
# Another major category of algorithm is sorting algorithms.
# Sorting algorithms are used to sort collections of elements
# into order (numerical order for numbers, etc.).
# ------------------------------------------------------------

# --------------------
# BUBBLE SORT
# --------------------
def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    n = len(arr)
    for i in range(n):
        swapped = False  # Optimization: check if any swaps occurred
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]  # Swap elements
                swapped = True
        if not swapped:  # Exit early if the list is already sorted
            break
    return arr


# --------------------
# INSERTION SORT
# --------------------
def insertion_sort(arr):
    """
    Insertion Sort: Builds the final sorted array one item at a time.
    Takes each element from the input list and inserts it into its
    correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr


# --------------------
# TESTING BUBBLE SORT AND INSERTION SORT
# --------------------
# Instead of the original single example, we now test for multiple data sizes
sizes = [5, 10, 15]  # Small lists for demonstration

for size in sizes:
    unsorted_list = [random.randint(1, 100) for _ in range(size)]
    print("\nOriginal list:", unsorted_list)

    # Bubble Sort
    bubble_sorted = bubble_sort(unsorted_list.copy())
    print("Bubble sorted:", bubble_sorted)

    # Insertion Sort
    insertion_sorted = insertion_sort(unsorted_list.copy())
    print("Insertion sorted:", insertion_sorted)

    # Timing execution for comparison
    bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
    insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)

    print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
    print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")


# --------------------
# BINARY SEARCH ON UNSORTED LIST WITH SORTING
# --------------------
# Demonstrates that binary search requires sorted data. If we only have
# unsorted data, sorting must be done first, which adds extra time.
def binary_search_sorted(array, target):
    array = insertion_sort(array)
    result = binary_search(array, target)
    return result

unsorted_list = [random.randint(1, 1000) for _ in range(10000)]
target = random.randint(1, 1000)

binary_time = timeit.timeit(lambda: binary_search_sorted(unsorted_list, target), number=1)
linear_time = timeit.timeit(lambda: linear_search(unsorted_list, target), number=1)

print(f"\nBinary Search (With Sorting) Execution Time: {binary_time:.6f} seconds")
print(f"Linear Search Execution Time: {linear_time:.6f} seconds")

# One takeaway: The most efficient algorithm on paper isn't always the most
# efficient in practice. If binary search requires sorted data, and we only
# have unsorted data, we must consider the cost of sorting. In some cases,
# linear search can actually be faster.