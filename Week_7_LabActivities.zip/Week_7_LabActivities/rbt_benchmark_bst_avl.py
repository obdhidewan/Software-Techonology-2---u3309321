import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt

# ===== BST =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        while root.left:
            root = root.left
        return root

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name, root.phone = temp.name, temp.phone
            root.right = self.delete(root.right, temp.name)
        return root


# ===== AVL =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        while node.left:
            node = node.left
        return node

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if not root.left:
                return root.right
            elif not root.right:
                return root.left

            temp = self.min_value_node(root.right)
            root.name, root.phone = temp.name, temp.phone
            root.right = self.delete(root.right, temp.name)

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)


# ===== RED-BLACK TREE =====

class RBNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.color = "RED"
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None)
        self.NIL.color = "BLACK"
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert(self, name, phone):
        node = RBNode(name, phone)
        node.left = self.NIL
        node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if node.name < current.name:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node

        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == "RED":
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == "RED":
                    u.color = "BLACK"
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == "RED":
                    u.color = "BLACK"
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    self.right_rotate(k.parent.parent)

            if k == self.root:
                break

        self.root.color = "BLACK"

    def search(self, node, name):
        if node == self.NIL or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)


# ===== BENCHMARK =====

def benchmark(n=1000):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, int(n * 0.5))

    # BST
    bst = BST()
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert = time.time() - start

    start = time.time()
    for name in search_names:
        bst.search(bst.root, name)
    bst_search = time.time() - start

    start = time.time()
    for name in search_names[:100]:
        bst.root = bst.delete(bst.root, name)
    bst_delete = time.time() - start

    # AVL
    avl = AVLTree()
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert = time.time() - start

    start = time.time()
    for name in search_names:
        avl.search(avl.root, name)
    avl_search = time.time() - start

    start = time.time()
    for name in search_names[:100]:
        avl.root = avl.delete(avl.root, name)
    avl_delete = time.time() - start

    # RBT
    rbt = RedBlackTree()
    start = time.time()
    for i in range(n):
        rbt.insert(names[i], phones[i])
    rbt_insert = time.time() - start

    start = time.time()
    for name in search_names:
        rbt.search(rbt.root, name)
    rbt_search = time.time() - start

    rbt_delete = 0  # not implemented

    return {
        "insert": (bst_insert, avl_insert, rbt_insert),
        "search": (bst_search, avl_search, rbt_search),
        "delete": (bst_delete, avl_delete, rbt_delete)
    }


# ===== GRAPH =====

def run_benchmark_for_sizes(sizes):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        results = benchmark(n)

        for op in ['insert', 'search', 'delete']:
            bst_times[op].append(results[op][0])
            avl_times[op].append(results[op][1])
            rbt_times[op].append(results[op][2])

    plt.figure(figsize=(12, 8))

    for i, op in enumerate(['insert', 'search', 'delete'], 1):
        plt.subplot(3, 1, i)
        plt.plot(sizes, bst_times[op], label='BST')
        plt.plot(sizes, avl_times[op], label='AVL')
        plt.plot(sizes, rbt_times[op], label='RBT')
        plt.title(f"{op.capitalize()} Time")
        plt.ylabel("Time (s)")
        plt.legend()

    plt.xlabel("Number of Nodes")
    plt.tight_layout()
    plt.show()


# ===== GUI =====

class BenchmarkApp:
    def __init__(self, master):
        master.title("BST vs AVL vs RBT")

        tk.Button(master, text="Run Benchmark", command=self.run).pack(pady=5)
        tk.Button(master, text="Run Graph Benchmark", command=self.run_graphs).pack(pady=5)

        self.text = tk.Text(master, height=15, width=60)
        self.text.pack()

    def run(self):
        results = benchmark(5000)

        self.text.delete(1.0, tk.END)

        self.text.insert(tk.END,
            f"INSERT:\nBST: {results['insert'][0]:.5f} | AVL: {results['insert'][1]:.5f} | RBT: {results['insert'][2]:.5f}\n\n"
            f"SEARCH:\nBST: {results['search'][0]:.5f} | AVL: {results['search'][1]:.5f} | RBT: {results['search'][2]:.5f}\n\n"
            f"DELETE:\nBST: {results['delete'][0]:.5f} | AVL: {results['delete'][1]:.5f} | RBT: N/A\n"
        )

    def run_graphs(self):
        run_benchmark_for_sizes([100, 500, 1000, 2000])


# ===== MAIN =====

if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()