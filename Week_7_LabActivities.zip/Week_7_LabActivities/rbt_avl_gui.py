import tkinter as tk
from tkinter import messagebox

# === AVL Tree Node ===
class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


# === AVL Tree Class ===
class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))

        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))

        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node

        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def inorder(self, root, res=None):
        if res is None:
            res = []
        if root:
            self.inorder(root.left, res)
            res.append((root.name, root.phone))
            self.inorder(root.right, res)
        return res


# ===== RED-BLACK TREE =====

class RBNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.color = "RED"
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None)
        self.NIL.color = "BLACK"
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert(self, name, phone):
        node = RBNode(name, phone)
        node.left = self.NIL
        node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if name < current.name:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent is None:
            self.root = node
        elif name < parent.name:
            parent.left = node
        else:
            parent.right = node

        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == "RED":
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
            else:
                u = k.parent.parent.right

            if u.color == "RED":
                u.color = "BLACK"
                k.parent.color = "BLACK"
                k.parent.parent.color = "RED"
                k = k.parent.parent
            else:
                if k.parent == k.parent.parent.right:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    self.left_rotate(k.parent.parent)
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "BLACK"
                    k.parent.parent.color = "RED"
                    self.right_rotate(k.parent.parent)

            if k == self.root:
                break

        self.root.color = "BLACK"

    def search(self, node, name):
        if node == self.NIL or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.name, node.phone))
            self.inorder(node.right, res)
        return res


# === Tkinter GUI App ===

class AVLApp:
    def __init__(self, master):
        self.avl = AVLTree()
        self.rbt = RedBlackTree()
        self.tree_type = tk.StringVar(value="AVL")

        self.master = master
        master.title("AVL Contact Directory")

        tk.Radiobutton(master, text="AVL", variable=self.tree_type, value="AVL").pack()
        tk.Radiobutton(master, text="Red-Black Tree", variable=self.tree_type, value="RBT").pack()

        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1)

        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    def get_tree(self):
        return self.avl if self.tree_type.get() == "AVL" else self.rbt

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return

        tree = self.get_tree()

        if self.tree_type.get() == "AVL":
            tree.root = tree.insert(tree.root, name, phone)
        else:
            tree.insert(name, phone)

        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        tree = self.get_tree()

        if self.tree_type.get() == "AVL":
            node = tree.search(tree.root, name)
        else:
            node = tree.search(tree.root, name)
            if node == tree.NIL:
                node = None

        self.output_text.delete(1.0, tk.END)

        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()

        if self.tree_type.get() == "RBT":
            messagebox.showinfo("Info", "Delete not implemented for RBT")
            return

        self.avl.root = self.avl.delete(self.avl.root, name)

        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        tree = self.get_tree()

        if self.tree_type.get() == "AVL":
            contacts = tree.inorder(tree.root)
        else:
            contacts = tree.inorder(tree.root)

        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for n, p in contacts:
                self.output_text.insert(tk.END, f"Name: {n}, Phone: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")

        tree = self.get_tree()

        if self.tree_type.get() == "AVL":
            if not tree.root:
                return
            width = self.canvas.winfo_width()
            self._draw_node(tree.root, width // 2, 20, width // 4)

        else:
            if tree.root == tree.NIL:
                return
            width = self.canvas.winfo_width()
            self._draw_node_rbt(tree.root, width // 2, 20, width // 4)

    def _draw_node(self, node, x, y, x_offset):
        if not node:
            return

        radius = 20

        if node.left:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, x_offset // 2)

        if node.right:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, x_offset // 2)

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill="lightgreen")

        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        self.canvas.create_text(x, y, text=display_name, font=("Arial", 10, "bold"))

    def _draw_node_rbt(self, node, x, y, x_offset):
        tree = self.rbt

        if node == tree.NIL:
            return

        radius = 20

        if node.left != tree.NIL:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node_rbt(node.left, x_left, y_left, x_offset // 2)

        if node.right != tree.NIL:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node_rbt(node.right, x_right, y_right, x_offset // 2)

        color = "red" if node.color == "RED" else "black"

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)

        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        self.canvas.create_text(x, y, text=display_name, fill="white", font=("Arial", 10, "bold"))


# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = AVLApp(root)
    root.mainloop()